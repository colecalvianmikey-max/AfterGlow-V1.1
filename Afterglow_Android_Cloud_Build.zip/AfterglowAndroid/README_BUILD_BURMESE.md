# Afterglow Android APK ပြုလုပ်နည်း

ဒီဖိုင်က Android Studio project source ဖြစ်ပါတယ်။ APK ကို ဒီ ZIP တစ်ခုတည်းနဲ့ ဖုန်းမှာ တိုက်ရိုက် install မလုပ်နိုင်သေးပါဘူး — Android Studio/Android SDK နဲ့ Build လုပ်ရပါမယ်။

## APK Build လုပ်ရန်
1. ဒီ ZIP ကို Windows/macOS/Linux ကွန်ပျူတာမှာ Extract လုပ်ပါ။
2. Android Studio ကိုဖွင့်ပြီး **Open** ကိုနှိပ်ကာ `AfterglowAndroid` folder ကိုရွေးပါ။
3. Gradle sync ပြီးဆုံးအောင်စောင့်ပါ။ Internet လိုနိုင်ပါတယ်။
4. **Build > Build Bundle(s) / APK(s) > Build APK(s)** ကိုရွေးပါ။
5. Build အောင်မြင်ရင် `app/build/outputs/apk/debug/app-debug.apk` ကိုရပါမယ်။
6. APK ကို Android ဖုန်းထဲကူးပြီး ဖွင့်ပါ။ ဖုန်းက “Install unknown apps” ခွင့်ပြုရန် မေးလျှင် ကိုယ်ယုံကြည်ရတဲ့ APK ဖြစ်ကြောင်း စစ်ပြီးမှ ခွင့်ပြုပါ။

## App လုပ်ဆောင်ချက်
- App ကိုဖွင့်ရန် Internet မလိုဘဲ UI ကိုဖွင့်နိုင်ပါတယ်။
- Album/Artist search နဲ့ track list ရယူမှုအတွက် Internet လိုပါတယ်။
- Rating/Review တွေကို ဒီ app ရဲ့ WebView local storage ထဲမှာ သိမ်းပါတယ်။
- ဒီဗားရှင်းမှာ public shared database/accounts မပါသေးပါ။ လူတိုင်းရဲ့ ratings/reviews ကို အတူမြင်နိုင်ဖို့ backend လိုပါတယ်။
