AFTERGLOW — ဖုန်းတစ်လုံးတည်းဖြင့် Cloud မှ APK တည်ဆောက်ရန်

ဒီ ZIP သည် APK ကိုယ်တိုင် မဟုတ်ပါ။ GitHub Actions က အွန်လိုင်းမှာ APK build လုပ်ပေးနိုင်ရန် workflow ပါဝင်သော Android Studio project source ဖြစ်သည်။

အဆင့်များ
1. ZIP ကို Android ဖုန်းတွင် Download လုပ်ပြီး Files app ဖြင့် Extract လုပ်ပါ။ အတွင်းမှ AfterglowAndroid folder ကိုဖွင့်ပါ။
2. https://github.com တွင် ကိုယ်ပိုင် account ဖြင့် ဝင်ပါ။ New repository ဖန်တီးပြီး အမည်ကို Afterglow ထားပါ။ Public/Private ကိုရွေးနိုင်သည်။ Private ကိုရွေးလျှင် source ကို အခြားသူများ မမြင်နိုင်ပါ။
3. Repository ထဲတွင် Add file > Upload files ကိုနှိပ်ပါ။ ဖုန်း Browser ၏ Desktop site ကိုဖွင့်ထားရနိုင်သည်။ Extract လုပ်ထားသော AfterglowAndroid folder အတွင်းရှိ ဖိုင်များနှင့် .github folder ကို repository root ထဲသို့ တင်ပါ။ Folder structure မပျက်စေရပါ။ အထူးသဖြင့် .github/workflows/build-apk.yml ဖိုင်လမ်းကြောင်းကို အတိအကျ ထိန်းထားပါ။
4. Commit changes ကိုနှိပ်ပါ။ Push to main ဖြစ်သွားလျှင် Actions tab တွင် “Build Afterglow APK” workflow စတင်မည်။ မစလျှင် Actions > Build Afterglow APK > Run workflow ကိုနှိပ်ပါ။
5. Workflow ပြီးဆုံးပြီး အစိမ်းရောင် success ဖြစ်လျှင် run ကိုဖွင့်ပါ။ အောက်ဆုံး Artifacts မှ “Afterglow-debug-APK” ကို Download လုပ်ပါ။ ZIP artifact ကို Extract လုပ်ပြီး app-debug.apk ကိုဖွင့်ကာ Install လုပ်ပါ။
6. Android က တားဆီးပါက Settings တွင် ထို browser/File Manager အတွက် “Install unknown apps” ခွင့်ပြုချက်ကို ကိုယ်တိုင်စစ်ဆေးပါ။ မသိသော APK များကို မတပ်ဆင်ပါနှင့်။

သတိပြုရန်
- GitHub အကောင့်ဝင်ရန်၊ repository ဖန်တီးရန်၊ upload/build လုပ်ရန် Internet လိုသည်။
- GitHub password သို့မဟုတ် Personal Access Token ကို မည်သူ့ကိုမျှ မပေးပါနှင့်။ APK build လုပ်ရန် token မလိုပါ။
- Source code ကို private ထားချင်လျှင် Private repository ရွေးပါ။
- APK သည် debug build ဖြစ်သည်။ Play Store တင်ရန် production signing နှင့် အခြားပြင်ဆင်မှုများ လိုနိုင်သည်။
- App အတွင်း Rating/Review များသည် လက်ရှိ local storage အခြေခံဖြစ်ပြီး လူတိုင်းကြား shared database မပါဝင်ပါ။
